package game.dori.service;

import game.dori.vo.ADDRESS_VO;

public interface AddressService {
	
	int insert(ADDRESS_VO addressVO);
}
