package game.dori.service;

public interface ProductService {

}
