package game.dori.service;

public interface CustomerscService {

}
