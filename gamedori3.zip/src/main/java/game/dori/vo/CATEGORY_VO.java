package game.dori.vo;

/*	ī�װ� ���̺�	*/

public class CATEGORY_VO {


	private int cate_code;			// 카테고리 코드 (품번)
	private String cate_name;		// 이름
	private int cate_refcode;		// 참조 코드
	
	public int getCate_code() {
		return cate_code;
	}
	public void setCate_code(int cate_code) {
		this.cate_code = cate_code;
	}
	public String getCate_name() {
		return cate_name;
	}
	public void setCate_name(String cate_name) {
		this.cate_name = cate_name;
	}
	public int getCate_refcode() {
		return cate_refcode;
	}
	public void setCate_refcode(int cate_refcode) {
		this.cate_refcode = cate_refcode;
	}
	
	
}
